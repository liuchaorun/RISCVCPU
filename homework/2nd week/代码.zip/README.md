# RISCVCPU

代码位于 RISCVCPU\RISCV\RISCV.srcs\sources_1\new下

开发环境：vivado 2018.3

## 使用方法

1. 使用vivado打开RISCV项目文件
2. 点击TOP->if_unit:IF->instMem
3. 选择加载Fibonacci.coe文件加载后
4. 点击运行仿真
5. 若仿真正确，寄存器和RAM值如文档中所示